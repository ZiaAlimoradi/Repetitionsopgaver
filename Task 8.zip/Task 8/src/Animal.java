public abstract class Animal {

        public abstract void makeSound();

        public String isMammal;

        Animal(String isMammal){

            this.isMammal = isMammal;

        }

    }

