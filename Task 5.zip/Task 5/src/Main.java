public class Main {
    public static void main(String[] args) {

        Dialog dialog = new Dialog(2023);
        dialog.getYearOfBirth();

    }
}