public class Parrot extends Animal{

    public void makeSound(){
        System.out.println("Hello, world");
    }

    Parrot(String isMammal) {
        super(isMammal);
    }

}