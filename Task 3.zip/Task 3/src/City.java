public class City {

    private String name;

    private int population;

    City(String name, int populaion) {
        this.name = name;
        this.population = populaion;

    }

    public String getName() {
        return name;
    }

    public int getPopulation() {
        return population;
    }


}
