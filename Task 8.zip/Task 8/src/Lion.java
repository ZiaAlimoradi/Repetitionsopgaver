public class Lion extends Animal{

    public void makeSound() {
        System.out.println("Rooooar");
    }
    Lion(String isMammal) {
        super(isMammal);
    }
}
